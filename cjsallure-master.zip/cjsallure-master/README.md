This repo contains **CodeceptJS tests for TodoMVC application with Allure Report** 

# Installation

This is a playground for your first steps in testing, so instead of installing it from NPM it is recommended to clone it from repo instead.

1) Clone this repository

```
git clone git@gitlab.com:otusQA/cjsallure.git
```

2) Install dependencies via npm:

```
npm i
```

3) 
```
npm test
```