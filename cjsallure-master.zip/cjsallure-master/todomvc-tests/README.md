# Testing "Create TODOs" using page objects

- Create single todo
- Create multiple todos